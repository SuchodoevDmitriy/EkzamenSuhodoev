﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СуходоевЭкз
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "суходоевЭкзDataSet.Клиент". При необходимости она может быть перемещена или удалена.
            this.клиентTableAdapter.Fill(this.суходоевЭкзDataSet.Клиент);

        }

        private void button1_Click(object sender, EventArgs e)
        {
                        try
            {
                using (СуходоевЭкзEntities Voz = new СуходоевЭкзEntities())
                {
                    Клиент a = new Клиент()
                    {
                        Фамилия = Convert.ToString(textBox1.Text),

                        Имя = Convert.ToString(textBox2.Text),

                        Отчество = Convert.ToString(textBox3.Text),

                       Номер_телефона = Convert.ToString(textBox4.Text),

                      Эл_почта = Convert.ToString(textBox5.Text),
                    };
                    Voz.Клиент.Add(a);
                    Voz.SaveChanges();
                }
            }
            catch { MessageBox.Show("Ошибка при добавлении!"); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 Formmdb = new Form1();
            this.Hide();
            Formmdb.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (var db = new СуходоевЭкзEntities())
            {
                if(dataGridView1.SelectedRows.Count > 0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    int id = 0;
                    bool converted = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
                    if (converted == false)
                        return;
                    Клиент users = db.Клиент.Find(id);
                    db.Клиент.Remove(users);
                    db.SaveChanges();
                    MessageBox.Show("Строка успешно удалена!");

                }
            }    
        }
    }
}
